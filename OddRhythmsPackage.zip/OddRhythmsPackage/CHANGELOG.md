# Changelog

## [Unreleased]

### Added

- Add additional instruments (include decay)
- Have harmony instruments change base on energy [above is requisite]

### Bugfixes

- Fixed threading issues when valence/energy change on seed.

## 1.0.1 2024-09-26

### Added

- Example script for programmatically creating and using the music generator.

### Bugfixes

- Fixed an issue where changing valence/energy during play could cause an error.
- The labels for valence and energy were switched...

## 1.0.0 2024-09-11

### Added

- Pretty much everything. Please see the Documentation~ folder.

