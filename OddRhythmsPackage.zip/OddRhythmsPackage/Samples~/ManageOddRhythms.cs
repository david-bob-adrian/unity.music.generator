using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using OddRhythms;

public class ManageOddRhythms : MonoBehaviour
{
    public OddRhythms.SeedObject seed;
    // Start is called before the first frame update
    void Start()
    {
        OddRhythms.OddRhythms oddRhythm = gameObject.AddComponent<OddRhythms.OddRhythms>();
        seed = oddRhythm.CreateRandomSeed(5, 5);
        seed.Play();
        StartCoroutine(ChangeSeedSettings());
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public IEnumerator ChangeSeedSettings()
    {
        float inc = -.01f;

        while (true)
        {
            yield return new WaitForSeconds(.5f);
            seed._valence += inc;
            if (seed._valence <= 1 || seed._valence >= 5)
            {
                inc *= -1;
            }
        }
    }
}
