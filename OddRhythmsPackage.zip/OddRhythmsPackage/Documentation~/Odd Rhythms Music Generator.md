# Odd Rhythms Music Generator

## Overview

This is a Unity component to generate and play background music, with a particular focus on rhythm.

## Package Contents

- CHANGELOG.md
- LICENSE.md
- OddRythym dll
  - OddRhythms
  - SeedObjectEditor (Ignore)
- package.json
- Documentation~
  - Odd Rhythms Music Generator.md
- Samples~
  - ManageOddRhythms.cs (Example of creating using the objects programmatically)

## Requirements

This was tested on Unity 2019.1 and 2022.3.45f1; it should work on any versions between, and will probably work on older and newer versions, though these haven't been tested.

## Workflows

1. Go to the package
2. Click the arrow next to the OddRythym Component
3. Drag the OddRhythm script to a GameObject
4. Generate seed(s) on the OddRhythm Component
5. Play the seed to hear what it sounds like
6. Modify the valence and energy settings to change the feel of the seed.
7. Choose one seed to use in the actual scene.
8. The chosen seed will play when the scene is started.

Each seed has a field for notes to store whatever you want. Seeds can be favorited so you don't lose them.

## Reference

- UI
  - Main seed, which will be used in scene.
  - Array of up to 10 non-favorited seeds
  - Array of Favorite seeds
  - Each seed consists of:
    - Seed number (for random generator)
    - Energy (1-5): How energetic the piece should be (roughly, higher number = more notes)
    - Valence (1-5): Tougher to define; consonance vs. dissonance, with 5 being more dissonant.  
		   Once valence reaches 4 odd rhythms are possible.
    - Version: Which version of the generator to use; useful is you have a seed you really like, but an update would break it.
    - Note: Space to store whatever might be helpful about the seed (e.g. which energy/valence to use for what scenarios, anything to avoid, how you're feeling right now, etc)

  - Each seed in one of the arrays (not the main seed) has three buttons
    - Choose - copy to main seed (changing values in main will not change in chosen seed, and vice versa).
    - Toggle Favorite - Will add to favorites if not in favorites, or remove if it is.
    - Play/Stop - Starts playing this seed if none are playing, or stops any seed that is playing.

- API (Not necessary to use at all; untested)
  - OddRhythm
    - // fields
    - SeedObject seed // The main seed
    - SeedObject[] prevObject // An array of 10 unfavorited seeds
    - SeedObject[] favObject // An array of favorited seeds

    - // methods
    - SeedObject OddRhythm.CreateRandomSeed(float valence = 3, float energy = 3)
      Creates a new SeedObject with a random seed and the given valence and energy.

    - void OddRhythm.PlayOrStop(SeedObject seed)
      If this OddRhythm is playing something, it will stop it; otherwise, it will call OddRhythm.Play(seed).

    - void OddRhythm.Play(SeedObject seed)
      This will play the given seed, using the AudioSource attached to the same GameObject. If there is no AudioSource attached to the GameObject, this function will create one, which will be deleted when the seed is stopped.

      The attached AudioSource should have the "Loop" checkbox checked, and it should not have the tag "Finish", or it will be destroyed. Any attached AudioClip will be replaced by the Play function.

    - void OddRhythm.Stop()
      Stops whatever this OddRhythm is playing. If the AudioSource is tagged as Finish, it will be destroyed.


    - System.Collections.IEnumerator ChangeSeedSettings(SeedObject seed, float valence, float energy)
      Changes an already playing seed to have the given valence and energy, without stopping and restarting the music; there may be a slight delay, but it should be relatively seamless...

      If the given seed isn't playing, nothing will happen...

    - string GetRhythm()
      Returns a string containing the rhythms; each measure will (usually) be on its own line, separated by '\n'. The first value will be a number indicating the beats per minute (bpm); the rest will be how the beats are classified by the generator, either D, S, or W: D indicates the first beat of the measure (the "d"ownbeat), and is otherwise identical to S; S indicates a strong beat; W indicates a weak beat. A strong (or down) beat will be followed by 0-2 weak beats; the only time a strong beat will be followed by 0 weak beats is when the next beat is the down beat of the next measure, but otherwise 1 or 2 weak beats could happen equally.

      The song will loop back to the beginning once it ends. Some samples:

      "240 D W S W S W S W\n240 D W S W S W S W\n240 D ..."
      "240 D W W S W W S W\n480 D W S W W D W S W W\n240 D ..."

    - int GetMeasure()
      Gets the current measure (first measure is 1, not 0).

    - float GetBeat()
      Gets the current beat (first beat is 1, not 0). Please note the float return value; due to buffering, the returned value may skip over integral values, so if any tests are done on the value, they should be done as greater than or less than, not equal to. 

  - SeedObject
    - // members
    - int seed
    - float _valence
    - float _energy
    - string note
    - Version version

    - // methods
    - new SeedObject(int seed, OddRhythms parent, float valence = 3, float energy = 3, string note = "")
      Creates a new SeedObject attached to the parent OddRhythms with the given settings.

    - void SetValues(int seed, OddRhythms parent, float valence = 3, float energy = 3, string note = "")
      Sets the values of an already existing SeedObject.

    - void InitSeed()
      Creates the music; can be done during the loading of Objects, if you like. It is possible to call Play instead, which will call this function for you.

     - void Play()
       Causes the parent OddRhythms to play this seed; can only be done if a parent is attached...

     - string ToString()
       Returns a string representation of the Object: "Seed: seed; Val: valence; Energy: energy; 

  - enum Version
    - V1_0_0
    - V1_0_1